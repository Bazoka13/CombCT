:orphan:

All :program:`clang-modernize` transforms have moved to :doc:`clang-tidy/index`
(see the ``modernize`` module).
