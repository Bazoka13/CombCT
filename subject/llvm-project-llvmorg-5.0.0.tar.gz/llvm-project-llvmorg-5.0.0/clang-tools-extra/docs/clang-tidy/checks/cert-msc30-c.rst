.. title:: clang-tidy - cert-msc30-c
.. meta::
   :http-equiv=refresh: 5;URL=cert-msc50-cpp.html

cert-msc30-c
============

The cert-msc30-c check is an alias, please see
`cert-msc50-cpp <cert-msc50-cpp.html>`_ for more information.
