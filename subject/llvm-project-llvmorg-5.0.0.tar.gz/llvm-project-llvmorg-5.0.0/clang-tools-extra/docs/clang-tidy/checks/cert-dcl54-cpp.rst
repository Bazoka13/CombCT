.. title:: clang-tidy - cert-dcl54-cpp
.. meta::
   :http-equiv=refresh: 5;URL=misc-new-delete-overloads.html

cert-dcl54-cpp
==============

The cert-dcl54-cpp check is an alias, please see
`misc-new-delete-overloads <misc-new-delete-overloads.html>`_ for more
information.
