.. title:: clang-tidy - cert-err09-cpp
.. meta::
   :http-equiv=refresh: 5;URL=misc-throw-by-value-catch-by-reference.html

cert-err09-cpp
==============

The cert-err09-cpp check is an alias, please see
`misc-throw-by-value-catch-by-reference <misc-throw-by-value-catch-by-reference.html>`_
for more information.
