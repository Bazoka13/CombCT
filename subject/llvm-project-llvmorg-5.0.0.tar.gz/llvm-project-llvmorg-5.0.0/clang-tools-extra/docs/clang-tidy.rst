:orphan:

.. meta::
   :http-equiv=refresh: 0;URL='clang-tidy/'

clang-tidy documentation has moved here: http://clang.llvm.org/extra/clang-tidy/
