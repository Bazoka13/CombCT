A *toy* VS Code integration for development purposes.

Steps:
1. Make sure you have clangd in /usr/bin/clangd or edit src/extension.ts to
point to the binary.
2. Make sure you have nodejs and npm installed.
3. Make sure you have VS Code installed.
4. In order to start a development instance of VS code extended with this, run:
   $ npm install
   $ code .
   When VS Code starts, press <F5>.
