﻿namespace LLVM.ClangTidy
{
    static class PkgCmdIDList
    {
        public const uint cmdidClangTidy = 0x100;
    };
}